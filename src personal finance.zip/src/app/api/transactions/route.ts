import { NextResponse } from "next/server";
import connectDB from "@/db/connect";
import Transaction from "@/models/Transaction";

// GET All Transactions
export async function GET() {
  await connectDB();
  const transactions = await Transaction.find().sort({ date: -1 });
  return NextResponse.json(transactions);
}

// POST New Transaction
export async function POST(req: Request) {
  await connectDB();
  const { amount, date, description, category } = await req.json();
  const newTransaction = await Transaction.create({ amount, date, description, category });
  return NextResponse.json(newTransaction);
}
