
//step 2

// "use client";
// import { useState, useEffect } from "react";
// import AddTransaction from "@/components/AddTransaction";
// import TransactionList from "@/components/TransactionList";
// import SummaryCards from "@/components/SummaryCards";
// import MonthlyExpensesChart from "@/components/Charts/MonthlyExpensesChart";
// import CategoryPieChart from "@/components/Charts/CategoryPieChart";
// interface Transaction {
//   id: string;
//   amount: number;
//   date: string;
//   description: string;
// }
// const dummyTransactions = [
//   { id: "1", amount: 5000, date: "2024-02-01", description: "Salary", category: "Income" },
//   { id: "2", amount: -1500, date: "2024-02-02", description: "Groceries", category: "Food" },
//   { id: "3", amount: -2500, date: "2024-02-03", description: "Rent", category: "Housing" },
//   { id: "4", amount: -500, date: "2024-02-05", description: "Internet Bill", category: "Utilities" },
//   { id: "5", amount: -200, date: "2024-02-07", description: "Coffee", category: "Food" },
//   { id: "6", amount: -1000, date: "2024-02-10", description: "Shopping", category: "Entertainment" },
//   { id: "7", amount: -700, date: "2024-02-12", description: "Electricity Bill", category: "Utilities" },
//   { id: "8", amount: 2000, date: "2024-02-15", description: "Freelance Work", category: "Income" },
//   { id: "9", amount: -300, date: "2024-02-18", description: "Transport", category: "Travel" },
//   { id: "10", amount: -400, date: "2024-02-20", description: "Dining Out", category: "Food" }
// ];

// export default function Home() {
//   const [transactions, setTransactions] = useState<Transaction[]>(dummyTransactions);
  

//   // Load transactions from localStorage when component mounts
//   useEffect(() => {
//     const savedTransactions = localStorage.getItem("transactions");
//     if (savedTransactions) {
//       setTransactions(JSON.parse(savedTransactions));
//     }
//   }, []);

//   // Save transactions to localStorage whenever they change
//   useEffect(() => {
//     localStorage.setItem("transactions", JSON.stringify(transactions));
//   }, [transactions]);

//   // Function to add a new transaction
//   const handleAddTransaction = (newTransaction: Transaction) => {
//     setTransactions((prevTransactions) => [...prevTransactions, newTransaction]);
//   };

//   // ✅ Function to delete a transaction
//   const handleDeleteTransaction = (id: string) => {
//     setTransactions((prevTransactions) =>
//       prevTransactions.filter((transaction) => transaction.id !== id)
//     );
//   };

//   return (
//     <div className="max-w-2xl mx-auto p-4">
//       <h1 className="text-2xl font-bold">Personal Finance Tracker</h1>
//       <SummaryCards transactions={transactions} />
//       <AddTransaction onAddTransaction={handleAddTransaction} />
//       {/* ✅ Pass the delete function to TransactionList */}
//       <TransactionList transactions={transactions} onDeleteTransaction={handleDeleteTransaction} />
//       {/* ✅ Monthly Expenses Bar Chart */}
//       <div className="mt-6 p-4 bg-white rounded-lg shadow-md">
//         <h2 className="text-xl font-semibold mb-3">Monthly Expenses</h2>
//         <MonthlyExpensesChart transactions={transactions} />
//       </div>
//       <CategoryPieChart transactions={transactions} />
//        </div>
//   );
// }

//step 3
"use client";

import { useState, useEffect } from "react";
import AddTransaction from "@/components/AddTransaction";
import TransactionList from "@/components/TransactionList";
import SummaryCards from "@/components/SummaryCards";
import MonthlyExpensesChart from "@/components/Charts/MonthlyExpensesChart";
import CategoryPieChart from "@/components/Charts/CategoryPieChart";
import BudgetVsActualChart from "@/components/BudgetVsActualChart";
import Link from 'next/link';


interface Transaction {
  id: string;
  amount: number;
  date: string;
  description: string;
  category: string;
}

interface CategoryBudget {
  category: string;
  budget: number;
}

export default function Home() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [categoryBudgets, setCategoryBudgets] = useState<CategoryBudget[]>([]);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
 // Function to toggle the menu
 const toggleMenu = () => {
  setIsMenuOpen((prevState) => !prevState); // Toggle the state
};

  useEffect(() => {
    const savedTransactions = localStorage.getItem("transactions");
    const savedCategoryBudgets = localStorage.getItem("categoryBudgets");

    if (savedTransactions) {
      setTransactions(JSON.parse(savedTransactions));
    }

    if (savedCategoryBudgets) {
      setCategoryBudgets(JSON.parse(savedCategoryBudgets));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("transactions", JSON.stringify(transactions));
    localStorage.setItem("categoryBudgets", JSON.stringify(categoryBudgets));
  }, [transactions, categoryBudgets]);

  // Function to add a new transaction
  const handleAddTransaction = (newTransaction: Transaction) => {
    setTransactions((prevTransactions) => [...prevTransactions, newTransaction]);
  };

  // Function to delete a transaction
  const handleDeleteTransaction = (id: string) => {
    setTransactions((prevTransactions) =>
      prevTransactions.filter((transaction) => transaction.id !== id)
    );
  };

  // Function to set or update category budgets
  const handleSetCategoryBudget = (category: string, budget: number) => {
    setCategoryBudgets((prevBudgets) => {
      const updatedBudgets = prevBudgets.filter(
        (budget) => budget.category !== category
      );
      return [...updatedBudgets, { category, budget }];
    });
  };

  return (
    <div className="max-w-2xl mx-auto p-4">
     
     <div>
      {/* Navbar */}
      <nav className="navbar">
        <div className="navbar-logo">
          <img src="https://www.shutterstock.com/image-vector/icon-logo-financial-management-business-260nw-713387896.jpg" className="navbar-link">
            
          </img>
        </div>

        {/* Desktop Links */}
        <ul className={`navbar-links ${isMenuOpen ? 'open' : ''}`}>
          <li>
            <Link href="/" className="navbar-link">Home</Link>
          </li>
          <li>
            <Link href="/about" className="navbar-link">About Us</Link>
          </li>
          <li>
            <Link href="/" className="navbar-link">Finance Tracker</Link>
          </li>
          <Link href="/login" className="navbar-link">Login</Link>
        <br/>
       
        </ul>

        {/* Hamburger Menu Icon */}
        <div className="navbar-hamburger" onClick={toggleMenu}>
          <div className={`hamburger-icon ${isMenuOpen ? 'close' : ''}`}></div>
          <div className={`hamburger-icon ${isMenuOpen ? 'close' : ''}`}></div>
          <div className={`hamburger-icon ${isMenuOpen ? 'close' : ''}`}></div>
        </div>
      </nav>

      <br/>
      <br/>

      {/* Your content goes here */}
    </div>
      <h1 className="text-2xl font-bold">Personal Finance Tracker</h1>
     
      <SummaryCards transactions={transactions} categoryBudgets={categoryBudgets} />
      <BudgetVsActualChart transactions={transactions} categoryBudgets={categoryBudgets} />
      <h1>PieChart</h1>
      <CategoryPieChart transactions={transactions} />
      <MonthlyExpensesChart transactions={transactions} />
      
      {/* Budgeting Section */}
      <div className="mt-8">
        <h3 className="text-xl font-bold bg-orange-200">Set Monthly Budgets</h3>
        {["Food", "Entertainment", "Transport"].map((category) => (
          <div key={category} className="flex justify-between items-center mt-4">
            <span>{category}</span>
            <input
              type="number"
              placeholder="Set Budget"
              onChange={(e) =>
                handleSetCategoryBudget(category, parseFloat(e.target.value))
              }
              className="p-2 rounded"
            />
          </div>
        ))}
      </div>

      <TransactionList transactions={transactions} onDeleteTransaction={handleDeleteTransaction} />
      <AddTransaction onAddTransaction={handleAddTransaction} />
      
    </div>
  );
}
