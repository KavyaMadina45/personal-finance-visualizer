

//test 2

// import { useState } from "react";

// interface Transaction {
//   id: string;
//   amount: number;
//   date: string;
//   description: string;
// }

// interface AddTransactionProps {
//   onAddTransaction: (transaction: Transaction) => void;
// }

// export default function AddTransaction({ onAddTransaction }: AddTransactionProps) {
//   const [amount, setAmount] = useState("");
//   const [date, setDate] = useState("");
//   const [description, setDescription] = useState("");

//   const handleSubmit = (event: React.FormEvent) => {
//     event.preventDefault();

//     if (!amount || !date || !description) return;

//     const newTransaction: Transaction = {
//       id: Date.now().toString(),
//       amount: parseFloat(amount),
//       date: new Date(date).toISOString(),
//       description,
//     };

//     onAddTransaction(newTransaction);

//     // Clear input fields
//     setAmount("");
//     setDate("");
//     setDescription("");
//   };

//   return (
//     <form onSubmit={handleSubmit} className="flex flex-col gap-4 mt-6">
//       <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="Amount" className="p-2 rounded" required />
//       <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="p-2 rounded" required />
//       <input type="text" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Description" className="p-2 rounded" required />
//       <button type="submit" className="bg-blue-500 text-white p-2 rounded">Add Transaction</button>
//     </form>
//   );
// }

//test 3
"use client"; 
import { useState } from "react";

interface Transaction {
  id: string;
  amount: number;
  date: string;
  description: string;
  category: string; // Add category field
}

interface AddTransactionProps {
  onAddTransaction: (transaction: Transaction) => void;
}

const categories = ["Food", "Transportation", "Utilities", "Entertainment", "Other"]; // Predefined categories

export default function AddTransaction({ onAddTransaction }: AddTransactionProps) {
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState(""); // State for category

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();

    if (!amount || !date || !description || !category) return;

    const newTransaction: Transaction = {
      id: Date.now().toString(),
      amount: parseFloat(amount),
      date: new Date(date).toISOString(),
      description,
      category,
    };

    onAddTransaction(newTransaction);

    // Clear input fields
    setAmount("");
    setDate("");
    setDescription("");
    setCategory(""); // Clear category after submission
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4 mt-6">
      <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="Amount" className="p-2 rounded" required />
      <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="p-2 rounded" required />
      <input type="text" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Description" className="p-2 rounded" required />
      <select value={category} onChange={(e) => setCategory(e.target.value)} className="p-2 rounded" required>
        <option value="">Select Category</option>
        {categories.map((cat) => (
          <option key={cat} value={cat}>
            {cat}
          </option>
        ))}
      </select>
      <button type="submit" className="bg-blue-500 text-white p-2 rounded">Add Transaction</button>
    </form>
  );
}


