import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { format } from "date-fns";

interface Transaction {
  amount: number;
  date: string;
}

interface Props {
  transactions: Transaction[];
}

export default function MonthlyExpensesChart({ transactions }: Props) {
  // Filter only expenses (amount < 0)
  const expenseTransactions = transactions.filter((t) => t.amount < 0);

  // Aggregate expenses by month
  const monthlyExpenses: Record<string, number> = expenseTransactions.reduce((acc, transaction) => {
    const month = format(new Date(transaction.date), "MMM yyyy"); // Format date to 'Jan 2025'
    acc[month] = (acc[month] || 0) + Math.abs(transaction.amount);
    return acc;
  }, {} as Record<string, number>);

  // Convert object to array for Recharts
  const chartData = Object.keys(monthlyExpenses).map((month) => ({
    name: month,
    value: monthlyExpenses[month],
  }));

  return (
    <div className="bg-white p-4 rounded-lg shadow-md">
      <h3 className="text-lg font-semibold mb-3">Monthly Expenses</h3>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={chartData}>
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="value" fill="#FF6347" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
