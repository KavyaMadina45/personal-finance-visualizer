import { PieChart, Pie, Cell, Legend, Tooltip } from "recharts";

interface Transaction {
  id: string;
  amount: number;
  date: string;
  description: string;
  category: string;
}

interface CategoryPieChartProps {
  transactions: Transaction[];
}

export default function CategoryPieChart({ transactions }: CategoryPieChartProps) {
  // Group transactions by category
  const categoryData: { [key: string]: number } = transactions.reduce((acc, { category, amount }) => {
    if (amount < 0) { // Only track expenses (negative amounts)
      acc[category] = (acc[category] || 0) + Math.abs(amount);
    }
    return acc;
  }, {} as { [key: string]: number });

  const chartData = Object.keys(categoryData).map((category) => ({
    name: category,
    value: categoryData[category],
  }));

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#FF6347", "#FF1493"];

  return (
    <PieChart width={400} height={400}>
      <Pie
        data={chartData}
        dataKey="value"
        nameKey="name"
        cx="50%"
        cy="50%"
        outerRadius={150}
        label
      >
        {chartData.map((entry, index) => (
          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
        ))}
      </Pie>
      <Tooltip />
      <Legend />
    </PieChart>
  );
}
