//test 1
// interface SummaryProps {
//   transactions: { id: string; amount: number }[];
// }

// export default function SummaryCards({ transactions }: SummaryProps) {
//   const totalIncome = transactions
//     .filter((transaction) => transaction.amount > 0)
//     .reduce((sum, transaction) => sum + transaction.amount, 0); // ✅ Income only

//   const totalExpenses = transactions
//     .filter((transaction) => transaction.amount < 0)
//     .reduce((sum, transaction) => sum + Math.abs(transaction.amount), 0); // ✅ Expense as positive

//   const balance = totalIncome - totalExpenses; // ✅ Correct balance calculation

//   return (
//     <div className="flex justify-between my-4">
//       <div className="bg-green-500 text-white p-4 rounded-lg">
//         <h3 className="text-lg font-bold">Income</h3>
//         <p className="text-2xl">₹{totalIncome.toFixed(2)}</p>
//       </div>
//       <div className="bg-red-500 text-white p-4 rounded-lg">
//         <h3 className="text-lg font-bold">Expenses</h3>
//         <p className="text-2xl">₹{totalExpenses.toFixed(2)}</p>
//       </div>
//       <div className="bg-blue-500 text-white p-4 rounded-lg">
//         <h3 className="text-lg font-bold">Balance</h3>
//         <p className="text-2xl">₹{balance.toFixed(2)}</p>
//       </div>
//     </div>
//   );
// }

//test 2

// interface Transaction {
//   id: string;
//   amount: number;
//   date: string;
//   description: string;
//   category: string; // Add category field
// }

// interface SummaryProps {
//   transactions: Transaction[];
// }

// export default function SummaryCards({ transactions }: SummaryProps) {
//   const totalIncome = transactions
//     .filter((transaction) => transaction.amount > 0)
//     .reduce((sum, transaction) => sum + transaction.amount, 0);

//   const totalExpenses = transactions
//     .filter((transaction) => transaction.amount < 0)
//     .reduce((sum, transaction) => sum + Math.abs(transaction.amount), 0);

//   const balance = totalIncome - totalExpenses;

//   const categoryExpenses = transactions.reduce((acc, { amount, category }) => {
//     if (amount < 0) {
//       acc[category] = (acc[category] || 0) + Math.abs(amount);
//     }
//     return acc;
//   }, {} as { [key: string]: number }); // Category-wise expense breakdown

//   return (
//     <div className="flex flex-wrap justify-between my-4">
//       <div className="bg-green-500 text-white p-4 rounded-lg w-1/3">
//         <h3 className="text-lg font-bold">Income</h3>
//         <p className="text-2xl">₹{totalIncome.toFixed(2)}</p>
//       </div>
//       <div className="bg-red-500 text-white p-4 rounded-lg w-1/3">
//         <h3 className="text-lg font-bold">Expenses</h3>
//         <p className="text-2xl">₹{totalExpenses.toFixed(2)}</p>
//       </div>
//       <div className="bg-blue-500 text-white p-4 rounded-lg w-1/3">
//         <h3 className="text-lg font-bold">Balance</h3>
//         <p className="text-2xl">₹{balance.toFixed(2)}</p>
//       </div>

//       {/* Category Breakdown */}
//       <div className="w-full mt-4">
//         <h3 className="text-lg font-bold">Category Breakdown</h3>
//         <ul>
//           {Object.keys(categoryExpenses).map((category) => (
//             <li key={category}>
//               {category}: ₹{categoryExpenses[category].toFixed(2)}
//             </li>
//           ))}
//         </ul>
//       </div>
//     </div>
//   );
// }

//test 3
"use client";

import { useState, useEffect } from "react";

interface Transaction {
  id: string;
  amount: number;
  date: string;
  description: string;
  category: string; // Add category field for each transaction
}

interface CategoryBudget {
  category: string;
  budget: number;
}

interface SummaryProps {
  transactions: Transaction[];
  categoryBudgets: CategoryBudget[]; // Add this prop for category budgets
}

export default function SummaryCards({ transactions, categoryBudgets = [] }: SummaryProps) {
  const totalIncome = transactions
    .filter((transaction) => transaction.amount > 0)
    .reduce((sum, transaction) => sum + transaction.amount, 0);

  const totalExpenses = transactions
    .filter((transaction) => transaction.amount < 0)
    .reduce((sum, transaction) => sum + Math.abs(transaction.amount), 0);

  const balance = totalIncome - totalExpenses;

  // Ensure categoryBudgets is not undefined and has a fallback empty array
  const spendingInsights = (categoryBudgets || []).map(({ category, budget }) => {
    const actual = transactions
      .filter((transaction) => transaction.category === category)
      .reduce((sum, transaction) => sum + Math.abs(transaction.amount), 0);

    return {
      category,
      budget,
      actual,
      difference: budget - actual,
    };
  });

  return (
    <div>
      {/* Income, Expenses, Balance */}
      <div className="flex justify-between my-4">
        <div className="bg-green-500 text-white p-4 rounded-lg">
          <h3 className="text-lg font-bold">Income</h3>
          <p className="text-2xl">₹{totalIncome.toFixed(2)}</p>
        </div>
        <div className="bg-red-500 text-white p-4 rounded-lg">
          <h3 className="text-lg font-bold">Expenses</h3>
          <p className="text-2xl">₹{totalExpenses.toFixed(2)}</p>
        </div>
        <div className="bg-blue-500 text-white p-4 rounded-lg">
          <h3 className="text-lg font-bold">Balance</h3>
          <p className="text-2xl">₹{balance.toFixed(2)}</p>
        </div>
      </div>

      {/* Spending Insights */}
      <div className="mt-6">
        <h3 className="text-xl font-bold">Spending Insights</h3>
        {spendingInsights.length > 0 ? (
          <ul>
            {spendingInsights.map(({ category, budget, actual, difference }) => (
              <li key={category} className="py-2">
                <div className="flex justify-between">
                  <span className="font-semibold">{category}</span>
                  <span>Budget: ₹{budget.toFixed(2)}</span>
                  <span>Actual: ₹{actual.toFixed(2)}</span>
                  <span>Difference: ₹{difference.toFixed(2)}</span>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-gray-500">No spending insights available.</p>
        )}
      </div>
    </div>
  );
}

  
