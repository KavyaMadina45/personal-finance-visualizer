//test 1

// interface Transaction {
//   id: string;
//   amount: number;
//   date: string;
//   description: string;
// }

// interface TransactionListProps {
//   transactions: Transaction[];
//   onDeleteTransaction: (id: string) => void; // ✅ Define prop type
// }

// export default function TransactionList({ transactions, onDeleteTransaction }: TransactionListProps) {
//   return (
//     <div className="bg-white shadow-md p-4 rounded-lg mt-4 text-black">
//       <h2 className="text-xl font-bold mb-2">Transaction List</h2>
//       {transactions.length > 0 ? (
//         <ul>
//           {transactions.map((transaction) => (
//             <li key={transaction.id} className="border-b py-2 flex justify-between items-center">
//               <span className="font-semibold">{transaction.description}</span> -  
//               <span className="text-red-500"> ₹{transaction.amount.toFixed(2)}</span> on  
//               <span className="text-gray-600"> {new Date(transaction.date).toLocaleDateString()}</span>
//               {/* ✅ Use the onDeleteTransaction function */}
//               <button onClick={() => onDeleteTransaction(transaction.id)} className="bg-red-500 text-white px-2 py-1 rounded ml-4">
//                 Delete
//               </button>
//             </li>
//           ))}
//         </ul>
//       ) : (
//         <p className="text-gray-500">No transactions available.</p>
//       )}
//     </div>
//   );
// }

//test 2
interface Transaction {
  id: string;
  amount: number;
  date: string;
  description: string;
  category: string; // Add category field
}

interface TransactionListProps {
  transactions: Transaction[];
  onDeleteTransaction: (id: string) => void;
}

export default function TransactionList({ transactions, onDeleteTransaction }: TransactionListProps) {
  return (
    <div className="bg-white shadow-md p-4 rounded-lg mt-4 text-black">
      <h2 className="text-xl font-bold mb-2">Transaction List</h2>
      {transactions.length > 0 ? (
        <ul>
          {transactions.map((transaction) => (
            <li key={transaction.id} className="border-b py-2 flex justify-between items-center">
              <span className="font-semibold">{transaction.description}</span> -  
              <span className="text-red-500"> ₹{transaction.amount.toFixed(2)}</span> on  
              <span className="text-gray-600"> {new Date(transaction.date).toLocaleDateString()}</span> 
              <span className="text-blue-500">({transaction.category})</span> {/* Show category */}
              <button onClick={() => onDeleteTransaction(transaction.id)} className="bg-red-500 text-white px-2 py-1 rounded ml-4">
                Delete
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-gray-500">No transactions available.</p>
      )}
    </div>
  );
}
