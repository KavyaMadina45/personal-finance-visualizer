import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

// Defining the types for transactions and category budgets
interface Transaction {
  category: string;
  amount: number;
}

interface CategoryBudget {
  category: string;
  budget: number;
}

interface BudgetVsActualChartProps {
  transactions: Transaction[];
  categoryBudgets: CategoryBudget[];
}

const BudgetVsActualChart = ({ transactions, categoryBudgets }: BudgetVsActualChartProps) => {
  // Calculate the actual spending for each category
  const categorySpending: { [key: string]: number } = transactions.reduce(
    (acc: { [key: string]: number }, { category, amount }) => {
      acc[category] = (acc[category] || 0) + amount; // Accumulate spending for each category
      return acc;
    },
    {} // Initial empty object for the accumulator
  );

  // Prepare the data for the chart
  const chartData = categoryBudgets.map(({ category, budget }) => ({
    category,
    budget,
    actual: categorySpending[category] || 0, // If no spending for this category, set it to 0
  }));

  return (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart data={chartData}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="category" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Bar dataKey="budget" fill="#82ca9d" />
        <Bar dataKey="actual" fill="#8884d8" />
      </BarChart>
    </ResponsiveContainer>
  );
};

export default BudgetVsActualChart;
