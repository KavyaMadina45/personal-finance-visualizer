// src/utils/categories.ts

// src/utils/categories.ts

const defaultCategoryBudgets = [
    { category: "Food", budget: 500 },
    { category: "Transport", budget: 300 },
    { category: "Entertainment", budget: 200 },
    { category: "Bills", budget: 150 },
    { category: "Health", budget: 100 },
    { category: "Shopping", budget: 400 },
    { category: "Others", budget: 50 },
  ];
  
  // Assuming existingCategoryBudgets comes from some other state or file
  const existingCategoryBudgets = [
    { category: "Food", budget: 600 },  // Example: updated budget
    { category: "Shopping", budget: 450 },
    // Add other categories here if applicable
  ];
  
  // Merging default and existing budgets
  const categoryBudgets = [
    ...defaultCategoryBudgets,
    ...existingCategoryBudgets, // Merging existing with default budgets
  ];
  
  export default categoryBudgets;
  